
# UploadFlow

A streaming-first secure file ingestion pipeline for Node.js.

UploadFlow helps Node.js applications handle file uploads with signature-based file validation, streaming file-size enforcement, and pluggable storage adapters.

## Features

- Streaming-first file processing
- File type detection using file signatures
- MIME type validation
- Maximum file-size enforcement
- Pluggable storage adapters
- Local filesystem storage
- Abort and cancellation support
- Structured error handling
- TypeScript support

## Requirements

- Node.js >= 20

## Installation

```bash
npm install uploadflow
```

Or using pnpm:

```bash
pnpm add uploadflow
```

## Quick Start

```typescript
import {
    UploadEngine,
    LocalStorageAdapter,
} from "uploadflow";

import { createReadStream } from "node:fs";

const storage = new LocalStorageAdapter({
    directory: "./uploads",
});

const upload = new UploadEngine({
    maxFileSize: 5 * 1024 * 1024,
    allowedMimeTypes: [
        "image/jpeg",
        "application/pdf",
    ],
    storage,
});

const result = await upload.upload({
    stream: createReadStream("./example.pdf"),
    filename: "example.pdf",
});

console.log(result);
```

## Upload Result

A successful upload returns:

```typescript
{
    id: string;
    key: string;
    originalName: string;
    mimeType: string;
    size: number;
    status: "completed";
}
```

## Configuration

| Option | Type | Description |
|---|---|---|
| `maxFileSize` | `number` | Maximum allowed file size in bytes |
| `allowedMimeTypes` | `string[]` | Accepted MIME types |
| `storage` | `StorageAdapter` | Storage adapter used for uploads |

## Local Storage

UploadFlow includes a local filesystem storage adapter.

```typescript
const storage = new LocalStorageAdapter({
    directory: "./uploads",
});
```

The directory defaults to `./uploads` when not specified.

## Upload Cancellation

UploadFlow supports `AbortSignal`.

```typescript
const controller = new AbortController();

const uploadPromise = upload.upload({
    stream: createReadStream("./example.pdf"),
    filename: "example.pdf",
    signal: controller.signal,
});

// Cancel when required
controller.abort();

await uploadPromise;
```

## Error Handling

UploadFlow provides structured errors through `UploadError` and `UploadErrorCode`.

```typescript
import {
    UploadError,
    UploadErrorCode,
} from "uploadflow";

try {
    // Perform upload
} catch (error) {
    if (error instanceof UploadError) {
        console.log(error.code);
        console.log(error.message);
    }
}
```

## Custom Storage Adapters

You can implement the `StorageAdapter` interface to integrate your own storage provider.

```typescript
import type {
    StorageAdapter,
    StoredFile,
} from "uploadflow";

import type { Readable } from "node:stream";

class CustomStorage implements StorageAdapter {
    async upload(options: {
        key: string;
        stream: Readable;
        contentType: string;
        signal?: AbortSignal;
    }): Promise<StoredFile> {
        // Implement your storage logic

        return {
            key: options.key,
            size: 0,
        };
    }

    async delete(key: string): Promise<void> {
        // Implement deletion
    }
}
```

## License

MIT
```

**Important:** This is an initial README, not a final release document. The custom storage example is an interface illustration; its `size: 0` is a placeholder, not production upload logic.

After creating it, tell me. We'll review the examples against the actual implementation and improve anything that needs correction before publishing.